CREATE VIEW v_people_user AS
  SELECT
    `mcms`.`people`.`PEOPLE_ID`           AS `PEOPLE_ID`,
    `mcms`.`people`.`PEOPLE_PHONE`        AS `PEOPLE_PHONE`,
    `mcms`.`people`.`PEOPLE_NAME`         AS `PEOPLE_NAME`,
    `mcms`.`people`.`PEOPLE_PASSWORD`     AS `PEOPLE_PASSWORD`,
    `mcms`.`people`.`PEOPLE_DATETIME`     AS `PEOPLE_DATETIME`,
    `mcms`.`people`.`PEOPLE_APP_ID`       AS `PEOPLE_APP_ID`,
    `mcms`.`people`.`PEOPLE_MAIL`         AS `PEOPLE_MAIL`,
    `mcms`.`people`.`PEOPLE_STATE`        AS `PEOPLE_STATE`,
    `mcms`.`people`.`PEOPLE_CODE`         AS `PEOPLE_CODE`,
    `mcms`.`people`.`PEOPLE_CODESENDDATE` AS `PEOPLE_CODESENDDATE`,
    `mcms`.`people`.`PEOPLE_PHONECHECK`   AS `PEOPLE_PHONECHECK`,
    `mcms`.`people`.`PEOPLE_MAILLCHECK`   AS `PEOPLE_MAILLCHECK`,
    `mcms`.`people_user`.`PU_PEOPLE_ID`   AS `PU_PEOPLE_ID`,
    `mcms`.`people_user`.`PU_REAL_NAME`   AS `PU_REAL_NAME`,
    `mcms`.`people_user`.`PU_ADDRESS`     AS `PU_ADDRESS`,
    `mcms`.`people_user`.`PU_ICON`        AS `PU_ICON`,
    `mcms`.`people_user`.`PU_NICKNAME`    AS `PU_NICKNAME`,
    `mcms`.`people_user`.`PU_SEX`         AS `PU_SEX`,
    `mcms`.`people_user`.`PU_BIRTHDAY`    AS `PU_BIRTHDAY`,
    `mcms`.`people_user`.`PU_CARD`        AS `PU_CARD`,
    `mcms`.`people_user`.`PU_APP_ID`      AS `PU_APP_ID`
  FROM (`mcms`.`people`
    LEFT JOIN `mcms`.`people_user` ON ((`mcms`.`people`.`PEOPLE_ID` = `mcms`.`people_user`.`PU_PEOPLE_ID`)));
