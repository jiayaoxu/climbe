CREATE VIEW v_article AS
  SELECT
    `mcms`.`cms_article`.`ARTICLE_BASICID`      AS `ARTICLE_BASICID`,
    `mcms`.`basic`.`BASIC_ID`                   AS `BASIC_ID`,
    `mcms`.`basic`.`BASIC_CATEGORYID`           AS `BASIC_CATEGORYID`,
    `mcms`.`basic`.`BASIC_TITLE`                AS `BASIC_TITLE`,
    `mcms`.`basic`.`BASIC_DESCRIPTION`          AS `BASIC_DESCRIPTION`,
    `mcms`.`basic`.`BASIC_THUMBNAILS`           AS `BASIC_THUMBNAILS`,
    `mcms`.`basic`.`BASIC_HIT`                  AS `BASIC_HIT`,
    `mcms`.`basic`.`BASIC_DATETIME`             AS `BASIC_DATETIME`,
    `mcms`.`basic`.`BASIC_UPDATETIME`           AS `BASIC_UPDATETIME`,
    `mcms`.`basic`.`BASIC_PEOPLEID`             AS `BASIC_PEOPLEID`,
    `mcms`.`cms_article`.`ARTICLE_AUTHOR`       AS `ARTICLE_AUTHOR`,
    `mcms`.`cms_article`.`ARTICLE_CONTENT`      AS `ARTICLE_CONTENT`,
    `mcms`.`cms_article`.`ARTICLE_TYPE`         AS `ARTICLE_TYPE`,
    `mcms`.`cms_article`.`ARTICLE_SOURCE`       AS `ARTICLE_SOURCE`,
    `mcms`.`cms_article`.`ARTICLE_URL`          AS `ARTICLE_URL`,
    `mcms`.`cms_article`.`ARTICLE_KEYWORD`      AS `ARTICLE_KEYWORD`,
    `mcms`.`cms_article`.`ARTICLE_FREEORDER`    AS `ARTICLE_FREEORDER`,
    `mcms`.`cms_article`.`ARTICLE_WEBID`        AS `ARTICLE_WEBID`,
    `mcms`.`cms_column`.`COLUMN_KEYWORD`        AS `COLUMN_KEYWORD`,
    `mcms`.`cms_column`.`COLUMN_DESCRIP`        AS `COLUMN_DESCRIP`,
    `mcms`.`cms_column`.`COLUMN_TYPE`           AS `COLUMN_TYPE`,
    `mcms`.`cms_column`.`COLUMN_URL`            AS `COLUMN_URL`,
    `mcms`.`cms_column`.`COLUMN_LISTURL`        AS `COLUMN_LISTURL`,
    `mcms`.`cms_column`.`COLUMN_TENTMODELID`    AS `COLUMN_TENTMODELID`,
    `mcms`.`cms_column`.`COLUMN_WEBSITEID`      AS `COLUMN_WEBSITEID`,
    `mcms`.`cms_column`.`COLUMN_PATH`           AS `column_path`,
    `mcms`.`cms_column`.`COLUMN_CONTENTMODELID` AS `COLUMN_CONTENTMODELID`,
    `mcms`.`category`.`CATEGORY_TITLE`          AS `CATEGORY_TITLE`,
    `mcms`.`category`.`CATEGORY_APPID`          AS `CATEGORY_APPID`,
    `mcms`.`cms_column`.`COLUMN_CATEGORYID`     AS `COLUMN_CATEGORYID`,
    `mcms`.`category`.`CATEGORY_ID`             AS `CATEGORY_ID`,
    `mcms`.`basic`.`BASIC_SORT`                 AS `BASIC_SORT`
  FROM (((`mcms`.`basic`
    JOIN `mcms`.`cms_article` ON ((`mcms`.`basic`.`BASIC_ID` = `mcms`.`cms_article`.`ARTICLE_BASICID`))) JOIN
    `mcms`.`cms_column` ON ((`mcms`.`basic`.`BASIC_CATEGORYID` = `mcms`.`cms_column`.`COLUMN_CATEGORYID`))) JOIN
    `mcms`.`category` ON ((`mcms`.`cms_column`.`COLUMN_CATEGORYID` = `mcms`.`category`.`CATEGORY_ID`)));
